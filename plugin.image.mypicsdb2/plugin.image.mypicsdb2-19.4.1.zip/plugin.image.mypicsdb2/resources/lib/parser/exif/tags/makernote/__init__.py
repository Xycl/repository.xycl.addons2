"""
Makernote tag definitions.
"""
